Web Monitor - WordPress plugin

1. WordPress admin -> Plugins -> Add New -> Upload Plugin -> choose this zip -> Install -> Activate.
2. Settings -> Web Monitor API: copy the API key (generated on activation).
3. To update, download the zip again and upload it the same way. If WordPress says the plugin
   is already installed, choose Replace current with uploaded. The API key stays the same.
4. In the Web Monitor dashboard: Add site -> your site URL (https://your-site.com),
   platform WordPress, paste the API key.
