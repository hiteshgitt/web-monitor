Web Monitor - Core PHP integration (works for any PHP site)

1. Copy the api/ folder into your site root (your-site/api/webmonitor.php).
2. Edit api/webmonitor-config.php and set api_key (never put keys in a .env file inside the web root:
   many servers let anyone download it).
3. Route /api/webmonitor/* to the file.

   Apache - add to the .htaccess in your site root:
     RewriteEngine On
     RewriteRule ^api/webmonitor/(.*)$ api/webmonitor.php?endpoint=$1 [QSA,L]

   Nginx - inside your server block:
     location /api/webmonitor/ {
         rewrite ^/api/webmonitor/(.*)$ /api/webmonitor.php?endpoint=$1 last;
     }

Generate a long random API key, e.g.:
  openssl rand -hex 32
Use the same key in your site and in the Web Monitor dashboard.

In the dashboard: Add site -> platform Core PHP.
