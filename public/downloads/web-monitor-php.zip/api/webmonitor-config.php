<?php
// Web Monitor settings. This is a PHP file on purpose: the web server runs it instead of
// sending it, so your key can't be downloaded. Paste the same key into the dashboard.
return [
    'api_key' => 'paste-a-long-random-key-here',   // generate with: openssl rand -hex 32
    'site_url' => null,                            // e.g. 'https://your-site.com' (optional)
];
